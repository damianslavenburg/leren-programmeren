# ZeresPluginLibrary - [Download][download]

[download]: https://betterdiscord.app/Download?id=9

Zere's Plugin Library allows plugins to use modern APIs in the current version of BetterDiscord.

## Library Documentation

View the library documentation here: [https://rauenzi.github.io/BDPluginLibrary/docs](https://rauenzi.github.io/BDPluginLibrary/docs)